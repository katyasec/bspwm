#!/usr/bin/env bash

# settings
mode="light"
wall="fill"

# colors
bg="#f7e8f0"   
fg="#4b4a52"   
bl="#5a6786"   
wh="#f2f0f7"   
r="#f09292"    
g="#a8d0a3"    
y="#f5d6a1"    
b="#8caee5"    
m="#c9a0e6"    
c="#aadad5"    
br="#a69f9f"   
br2="#eb6b6b"  
