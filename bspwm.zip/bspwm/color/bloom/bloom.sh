#!/usr/bin/env bash

# settings
mode="light"
wall="fill"

# colors
bg="#fffaf5"
fg="#4b4646"
bl="#4b4646"
wh="#ebe6e1"
r="#eb8c8c"
g="#96e6a5"
y="#f0cd96"
b="#9bb9f0"
m="#d7a0e6"
c="#a0e1d2"
br="#9e9e9e"
br2="#eb8c8c"
