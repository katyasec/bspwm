#!/usr/bin/env bash

#settings
mode="light"
wall="fill"

# colors
fg="#bdb6b4"   # light grayish tone for the foreground (text and highlights)
bg="#412e3e"   # dark purple for background elements
wh="#efdbcc"   # soft off-white for contrast
r="#a5656f"    # muted red-pink for accents
g="#6a9cac"    # soft green-blue for subdued elements
y="#efdbcc"    # warm cream color for lighter accents
b="#412e3e"    # dark bluish-purple for shadows
m="#a5656f"    # matching pinkish-red for subtle highlights
c="#6a9cac"    # cyan-blue for balance
br="#000000"   # solid black for borders
br2="#efdbcc"  # warm cream for strong emphasis

