#!/usr/bin/env bash

# settings
mode="light"
wall="fill"

# colors
fg="#4e3a35"   # dark brownish-red for the foreground (text and highlights)
bg="#9d5155"   # muted red-pink for background elements
wh="#fefefe"   # bright white for contrast and clean elements
r="#9d5155"    # reddish-pink for accents and highlights
g="#c1ad9d"    # light beige-gray for softer, subdued elements
y="#eee1cf"    # warm cream color for subtle accents
b="#4e3a35"    # deep brown-red for shadow elements
m="#9d5155"    # matching muted pink for highlights and subtle details
c="#c1ad9d"    # light beige-gray for balance and contrast
br="#000000"   # solid black for borders and outlines
br2="#eee1cf"  # warm cream color for strong emphasis and important elements

