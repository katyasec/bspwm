#!/usr/bin/env bash

# settings
mode="dark"
wall="fill"

# colors
bg="#1c1c1f"   # very dark gray/black from the background shadows
fg="#e2e2e5"   # soft gray for the foreground (text and highlights)
bl="#3d3f5c"   # muted blue-purple from the sky tones
wh="#f4f4f7"   # soft off-white for contrast
r="#e03e3e"    # intense red for accents (matching the eye)
g="#6e837d"    # darkened greenish-gray for subdued elements
y="#d7b89d"    # muted brownish-yellow for warmer accents
b="#4e548e"    # dark bluish-purple from the shadows
m="#9d6c9f"    # muted magenta for some subtle highlights
c="#59616d"    # dark cyan-gray for balance
br="#707070"   # gray for borders
br2="#e64545"  # bright red for strong emphasis

