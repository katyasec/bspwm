#!/usr/bin/env bash

# settings
mode="dark"
wall="fill"

# colors
fg="#14020e"   # dominant dark color for the foreground
bl="#160410"   # deep shade for background elements
wh="#11040e"   # dark red-purplish shade for highlights
r="#15030f"    # another dark red for accents
g="#170511"    # darker reddish shade for subdued elements
y="#13010d"    # dark tone for warmer accents
b="#150510"    # another deep red for shadow elements
m="#080510"    # deep purplish shade for subtle highlights
c="#03020a"    # very dark cyan-gray for balance
br="#180612"   # dark color for borders
br2="#e64545"  # kept bright red for strong emphasis

