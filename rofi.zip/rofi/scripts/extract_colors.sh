#!/bin/bash

# Function to generate a color palette from an image
generate_palette() {
  local image_path=$1
  local output_file="colors.txt"
  
  # Extract colors from the image
  convert "$image_path" -resize 100x100 -format %c -depth 8 histogram:info: | \
    awk -F ' ' '{print $2, $3}' | \
    sort | uniq -c | sort -nr | head -n 10 | \
    awk '{print $2}' | \
    xargs -I{} convert xc:{} -format '%[hex:u]' info: | \
    awk '{print $1}' | head -n 10 > "$output_file"

  # Read and format colors
  local color_names=("bg" "fg" "bl" "wh" "r" "g" "y" "b" "m" "c" "br" "br2")
  local count=0

  echo "# colors"
  while read -r color; do
    if [ $count -lt ${#color_names[@]} ]; then
      echo "${color_names[$count]}=\"$color\""
      ((count++))
    else
      break
    fi
  done < "$output_file"
}

# Main script
read -p "Enter the path to the image: " image_path

if [ -f "$image_path" ]; then
  generate_palette "$image_path"
else
  echo "File not found. Please provide a valid image path."
  exit 1
fi

